# Building from source

Requires an MSVC toolchain (Visual Studio Build Tools 2022 or full VS 2022,
"Desktop development with C++" workload).

1. Generate an import lib against **your own installed** `UE4SS.dll`
   (do this instead of trusting a redistributed `.lib`, so it always
   matches your exact UE4SS build):

   ```
   lib /def:UE4SS.def /out:UE4SS.lib /machine:x64
   ```

2. Compile and link:

   ```
   cl /LD /EHsc /std:c++20 /I include main.cpp /link UE4SS.lib /out:main.dll
   ```

Both commands must run from a "Developer Command Prompt for VS 2022" (or
after calling `vcvars64.bat`) so `cl`/`lib` are on PATH.

If `UE4SS.dll` exports change in a future UE4SS version, `lib /def:...`
will fail to resolve a symbol -- re-derive `UE4SS.def` with
`dumpbin /exports UE4SS.dll` and match the mangled names for
`CppUserModBase`'s constructor/destructor/virtuals.

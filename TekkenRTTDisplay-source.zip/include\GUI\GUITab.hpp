#pragma once

#include <utility>

#include <File/Macros.hpp>
// GUI.hpp intentionally NOT included here (pulls in ImGui, which isn't
// vendored/available in this trimmed-down local header set -- we don't
// construct or use GUITab in this mod, only need it to satisfy
// CppUserModBase's member declaration). `friend class DebuggingGUI` below
// implicitly forward-declares, so this is unaffected.

namespace RC
{
    class CppUserModBase;
}

namespace RC::GUI
{
    class GUITab
    {
        friend class DebuggingGUI;

      public:
        using RenderFunctionType = void (*)(CppUserModBase*);

      private:
        RenderFunctionType render_function{};
        CppUserModBase* owner{};
        StringType tab_name{};

      public:
        GUITab() = delete;
        GUITab(StringViewType name, RenderFunctionType render_function) : tab_name(name), render_function(render_function){};
        GUITab(StringViewType name, RenderFunctionType render_function, CppUserModBase* owner)
            : tab_name(name), render_function(render_function), owner(owner){};
        ~GUITab() = default;

      private:
        auto get_owner() -> CppUserModBase*
        {
            return owner;
        }
    };
} // namespace RC::GUI

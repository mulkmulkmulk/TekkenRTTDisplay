#include <Mod/CppUserModBase.hpp>

#include <Windows.h>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <thread>

namespace
{
    // RVA of DAT_149B83F20 (the RTT stats manager singleton pointer),
    // computed against image base 0x140000000: 0x149B83F20 - 0x140000000.
    // NOT the getter function FUN_145bd2c60 -- we read the global directly.
    constexpr uintptr_t SINGLETON_RVA = 0x9B83F20;

    constexpr ptrdiff_t MANAGER_LIST1_PTR_OFFSET = 0x28;
    constexpr ptrdiff_t MANAGER_LIST1_COUNT_OFFSET = 0x30;
    constexpr ptrdiff_t NODE_NEXT_OFFSET = 0x00;
    constexpr ptrdiff_t NODE_VALUE_OFFSET = 0x10;
    constexpr int MAX_SAMPLES = 64;

    struct ReadResult
    {
        bool ok{false};
        uintptr_t manager{0};
        uintptr_t list_ptr{0};
        int32_t count{0};
        int32_t samples[MAX_SAMPLES]{};
        uintptr_t node_addrs[MAX_SAMPLES]{};
        int sample_count{0};
    };

    // Isolated leaf function: only raw/POD locals, no C++ objects requiring
    // unwinding, so it's safe to wrap in SEH (__try/__except can't coexist
    // with automatic objects that have destructors in the same function).
    // ptr_offset/count_offset let this walk either sample collection off
    // the same manager.
    ReadResult safe_read_collection(uintptr_t base_address, ptrdiff_t ptr_offset, ptrdiff_t count_offset)
    {
        ReadResult result{};
        __try
        {
            uintptr_t singleton_addr = base_address + SINGLETON_RVA;
            uintptr_t manager = *reinterpret_cast<uintptr_t*>(singleton_addr);
            if (manager == 0)
            {
                return result;
            }
            result.manager = manager;

            uintptr_t list_ptr = *reinterpret_cast<uintptr_t*>(manager + ptr_offset);
            int32_t count = *reinterpret_cast<int32_t*>(manager + count_offset);
            result.list_ptr = list_ptr;
            result.count = count;

            if (list_ptr == 0 || count <= 0)
            {
                result.ok = true;
                return result;
            }

            // Walk as an intrusive linked list (next pointer at node+0x00),
            // NOT a fixed-stride array: a fixed-stride walk correctly read
            // index 0 (which coincides with list_ptr in both models) but
            // produced garbage for every later index, which is the exact
            // signature of a linked list being misread as a flat array.
            int to_read = count < MAX_SAMPLES ? count : MAX_SAMPLES;
            uintptr_t current = list_ptr;
            int i = 0;
            for (; i < to_read && current != 0; ++i)
            {
                result.node_addrs[i] = current;
                int32_t value = *reinterpret_cast<int32_t*>(current + NODE_VALUE_OFFSET);
                result.samples[i] = value;

                uintptr_t next = *reinterpret_cast<uintptr_t*>(current + NODE_NEXT_OFFSET);
                if (next == current)
                {
                    ++i;
                    break;
                }
                current = next;
            }
            result.sample_count = i;
            result.ok = true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            result = ReadResult{};
            result.ok = false;
        }
        return result;
    }

    void poll_loop()
    {
        HMODULE base = GetModuleHandleA(nullptr);
        if (!base)
        {
            return;
        }
        uintptr_t base_address = reinterpret_cast<uintptr_t>(base);

        // Single-line, overwritten every cycle -- this is the only file the
        // Lua side reads. No diagnostic files in the shipped build: keeping
        // disk I/O to one small write per cycle.
        const char* live_path = "TekkenRTT_live.txt";

        while (true)
        {
            ReadResult r = safe_read_collection(base_address, MANAGER_LIST1_PTR_OFFSET, MANAGER_LIST1_COUNT_OFFSET);

            double avg = 0.0;
            bool have_avg = false;
            if (r.ok && r.sample_count > 0)
            {
                long long sum = 0;
                for (int i = 0; i < r.sample_count; ++i)
                {
                    sum += r.samples[i];
                }
                avg = (double)sum / r.sample_count;
                have_avg = true;
            }

            FILE* lf = fopen(live_path, "w");
            if (lf)
            {
                if (have_avg)
                {
                    fprintf(lf, "%.1f\n", avg);
                }
                else
                {
                    fprintf(lf, "\n");
                }
                fclose(lf);
            }

            std::this_thread::sleep_for(std::chrono::milliseconds(500));
        }
    }
} // namespace

class TekkenRTTDisplay : public RC::CppUserModBase
{
  public:
    TekkenRTTDisplay()
    {
        ModName = STR("TekkenRTTDisplay");
        ModVersion = STR("1.0.0");
        ModDescription = STR("Reads the real pre-battle RTT directly from memory for the Lua display component");
        ModAuthors = STR("TekkenRTTDisplay"); // edit this to credit yourself
    }

    ~TekkenRTTDisplay() override = default;

    auto on_program_start() -> void override
    {
        std::thread(poll_loop).detach();
    }
};

extern "C" __declspec(dllexport) RC::CppUserModBase* start_mod()
{
    return new TekkenRTTDisplay();
}

extern "C" __declspec(dllexport) void uninstall_mod(RC::CppUserModBase* mod)
{
    delete mod;
}

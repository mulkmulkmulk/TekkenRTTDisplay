-- TekkenRTTDisplay
-- Shows the real pre-battle RTT (ms), read directly from the game's own
-- RTT statistics manager, on the matchmaking accept dialog -- instead of
-- only the bucketed antenna-bar quality indicator.
--
-- Pairs with the dlls/main.dll native component, which reads the raw RTT
-- samples from memory and writes the current average to TekkenRTT_live.txt
-- every 500ms. This script finds the live matchmaking dialog widget and
-- overwrites its "Disconnection Rate" label with that value.

print("[TekkenRTTDisplay] Loaded.")

local NATIVE_LIVE_FILE = "TekkenRTT_live.txt"
local DISPLAY_PREFIX = "Ping: "

-- Generation counter, not a single flag: a widget can remain IsValid()==true
-- even after it stops being the active/displayed dialog (e.g. backing out
-- of matchmaking from the menu instead of declining through the dialog),
-- so we can't rely on the old poll loop noticing it's stale on its own.
-- Any newly detected live dialog immediately claims a new generation; the
-- old loop checks its captured generation each tick and stops if superseded.
local current_generation = 0
-- True while a poll loop is actively ticking against some dialog instance.
-- The periodic backstop scan uses this to know when it needs to look for
-- (and resume polling against) a live dialog on its own, instead of relying
-- solely on NotifyOnNewObject firing.
local currently_polling = false

local last_displayed_rtt = nil
-- The last text we saw that the GAME itself authored (i.e. not our own
-- "Ping: ... ms | ..." overwrite) -- since we overwrite the same field,
-- naive change-detection would otherwise start tracking our own writes.
local last_game_disconnect_text = "Disconnection Rate: 0%"
local last_seen_widget_text = nil

local function read_native_live_rtt()
    local file = io.open(NATIVE_LIVE_FILE, "r")
    if not file then return nil end
    local line = file:read("*l")
    file:close()
    if not line or line == "" then return nil end
    return line
end

-- FText is a wrapper object -- :ToString() decodes it to a plain string.
local function decode_ftext(text_value)
    if text_value == nil then return nil end
    local ok_str, str_value = pcall(function() return text_value:ToString() end)
    if ok_str and str_value ~= nil then
        local ok_tostring, result = pcall(tostring, str_value)
        if ok_tostring then return result end
    end
    return nil
end

local function read_widget_text(widget_obj)
    if not widget_obj then return nil end
    local ok, text_value = pcall(function() return widget_obj:GetText() end)
    if ok and text_value ~= nil then
        return decode_ftext(text_value)
    end
    return nil
end

local function start_dialog_polling(dialog_obj, full_name)
    current_generation = current_generation + 1
    local my_generation = current_generation

    -- Fresh state for this dialog instance -- each new opponent gets a new
    -- WBP_UI_MatchDialog_Menu_C object, whose TB_DisconnectionRate starts
    -- back at the game's own default text, not our last overwrite.
    last_seen_widget_text = nil
    last_game_disconnect_text = "Disconnection Rate: 0%"
    last_displayed_rtt = nil
    currently_polling = true

    print("[TekkenRTTDisplay] Live matchmaking dialog found, displaying ping.")

    LoopAsync(500, function()
        -- A newer live dialog has already taken over (this one may still
        -- report IsValid()==true even though it's no longer the active
        -- dialog) -- stop quietly. Does NOT clear currently_polling, since
        -- a newer session is the one actually active now.
        if my_generation ~= current_generation then
            return true
        end

        -- pcall's first return is whether the CALL succeeded, not the
        -- IsValid() result itself -- must check both.
        local ok_valid, is_valid = pcall(function() return dialog_obj:IsValid() end)
        if not ok_valid or not is_valid then
            currently_polling = false
            return true
        end

        local ok_rate, rate_widget = pcall(function() return dialog_obj.TB_DisconnectionRate end)
        if not (ok_rate and rate_widget) then
            return false
        end

        local text_now = read_widget_text(rate_widget)
        if text_now ~= nil and text_now ~= last_seen_widget_text then
            last_seen_widget_text = text_now
            -- Only trust this as the game's own text if it's not our own
            -- previous overwrite (which would otherwise get echoed back to
            -- us on the very next poll).
            if text_now:sub(1, #DISPLAY_PREFIX) ~= DISPLAY_PREFIX then
                last_game_disconnect_text = text_now
            end
        end

        local rtt_now = read_native_live_rtt()
        if rtt_now ~= nil and rtt_now ~= last_displayed_rtt then
            last_displayed_rtt = rtt_now
            local combined = DISPLAY_PREFIX .. rtt_now .. " ms | " .. last_game_disconnect_text
            local ok_set = pcall(function()
                rate_widget:SetText(FText(combined))
            end)
            if ok_set then
                last_seen_widget_text = combined
            end
        end

        return false
    end)
end

local ok_notify = pcall(function()
    NotifyOnNewObject("/Script/UMG.UserWidget", function(new_widget)
        local ok_name, full_name = pcall(function() return new_widget:GetFullName() end)
        if not ok_name or not full_name then return end
        if not full_name:find("WBP_UI_MatchDialog_Menu_C", 1, true) then return end
        -- Only a genuine LIVE instance (not the archetype/CDO default
        -- child) is the actual matchmaking dialog.
        if not full_name:find("/Engine/Transient.", 1, true) then return end

        start_dialog_polling(new_widget, full_name)
    end)
end)
if not ok_notify then
    print("[TekkenRTTDisplay] NotifyOnNewObject registration failed")
end

-- Backstop: NotifyOnNewObject only fires on genuine construction, but the
-- game may reuse the same dialog widget instance across opponents (soft
-- show/hide) rather than constructing a fresh one every time. Kept cheap
-- since it runs for the whole game session, not just during matchmaking:
-- FindFirstOf (stops at first match) and a 2s interval.
LoopAsync(2000, function()
    if currently_polling then
        return false
    end

    local ok_scan, w = pcall(FindFirstOf, "WBP_UI_MatchDialog_Menu_C")
    if ok_scan and w then
        local ok_name, full_name = pcall(function() return w:GetFullName() end)
        if ok_name and full_name and full_name:find("/Engine/Transient.", 1, true) then
            local ok_valid, is_valid = pcall(function() return w:IsValid() end)
            if ok_valid and is_valid then
                start_dialog_polling(w, full_name)
            end
        end
    end

    return false
end)
